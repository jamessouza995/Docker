from .client import WebService, get_address_from_cep

__all__ = [
    'get_address_from_cep',
    'WebService',
]
